package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.HunterRank
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("System RPG", appName)
  }

  @Test
  fun `test hunter rank calculations`() {
    assertEquals(HunterRank.BEGINNER, HunterRank.fromXp(0))
    assertEquals(HunterRank.BEGINNER, HunterRank.fromXp(999))
    assertEquals(HunterRank.APPRENTICE, HunterRank.fromXp(1000))
    assertEquals(HunterRank.APPRENTICE, HunterRank.fromXp(4999))
    assertEquals(HunterRank.MASTER, HunterRank.fromXp(5000))
    assertEquals(HunterRank.MASTER, HunterRank.fromXp(9999))
    assertEquals(HunterRank.LEGEND, HunterRank.fromXp(10000))
    assertEquals(HunterRank.LEGEND, HunterRank.fromXp(50000))
  }
}
