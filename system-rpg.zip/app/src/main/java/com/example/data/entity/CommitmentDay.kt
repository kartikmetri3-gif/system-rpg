package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "commitment_days")
data class CommitmentDay(
    @PrimaryKey val dateKey: String, // e.g. "2026-08-18"
    val isCommitted: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
