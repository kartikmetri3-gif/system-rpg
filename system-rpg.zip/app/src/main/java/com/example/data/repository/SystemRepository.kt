package com.example.data.repository

import com.example.data.dao.SystemDao
import com.example.data.entity.CommitmentDay
import com.example.data.entity.DailyQuest
import com.example.data.entity.UserProfile
import com.example.data.entity.XpLog
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class SystemRepository(private val systemDao: SystemDao) {

    val userProfile: Flow<UserProfile?> = systemDao.getUserProfileFlow()
    val allQuests: Flow<List<DailyQuest>> = systemDao.getAllQuestsFlow()
    val totalCompletedQuestsCount: Flow<Int> = systemDao.getTotalCompletedQuestsCountFlow()
    val allCommitmentDays: Flow<List<CommitmentDay>> = systemDao.getAllCommitmentDaysFlow()
    val allXpLogs: Flow<List<XpLog>> = systemDao.getAllXpLogsFlow()

    fun getQuestsForDate(dateKey: String): Flow<List<DailyQuest>> =
        systemDao.getQuestsForDateFlow(dateKey)

    suspend fun getUserProfileDirect(): UserProfile? = systemDao.getUserProfile()

    suspend fun saveUserProfile(profile: UserProfile) {
        systemDao.insertOrUpdateProfile(profile)
    }

    suspend fun initializeDefaultQuestsForDate(dateKey: String): List<DailyQuest> {
        val existing = systemDao.getQuestsForDate(dateKey)
        if (existing.isNotEmpty()) {
            return existing
        }
        val defaultQuests = listOf(
            DailyQuest(
                dateKey = dateKey,
                goalIndex = 0,
                title = "Academic Mastery: Deep Study Session (2h)",
                category = "ACADEMICS",
                isCompleted = false,
                xpValue = 33
            ),
            DailyQuest(
                dateKey = dateKey,
                goalIndex = 1,
                title = "Health Protocol: High Intensity Physical Training",
                category = "HEALTH",
                isCompleted = false,
                xpValue = 33
            ),
            DailyQuest(
                dateKey = dateKey,
                goalIndex = 2,
                title = "Skill Execution: Build & Refine Core Craft",
                category = "SKILLS",
                isCompleted = false,
                xpValue = 34
            )
        )
        systemDao.insertQuests(defaultQuests)
        return defaultQuests
    }

    suspend fun updateQuestContent(id: Long, title: String, category: String) {
        systemDao.updateQuestContent(id, title, category)
    }

    suspend fun toggleQuestCompletion(quest: DailyQuest): Pair<Int, Boolean> {
        val newStatus = !quest.isCompleted
        systemDao.setQuestCompleted(quest.id, newStatus)

        val profile = systemDao.getUserProfile() ?: UserProfile()
        val xpDelta = if (newStatus) quest.xpValue else -quest.xpValue
        val newXp = (profile.totalXp + xpDelta).coerceAtLeast(0)

        systemDao.updateXp(newXp)

        if (newStatus) {
            systemDao.insertXpLog(
                XpLog(
                    dateKey = quest.dateKey,
                    xpEarned = quest.xpValue,
                    totalXpAfter = newXp,
                    reason = "Completed: ${quest.title.take(30)}"
                )
            )
            // Auto mark commitment for today if completed a goal
            val existingCommitment = systemDao.getCommitmentDay(quest.dateKey)
            if (existingCommitment == null) {
                systemDao.insertCommitmentDay(CommitmentDay(dateKey = quest.dateKey, isCommitted = true))
            }
        }

        return Pair(newXp, newStatus)
    }

    suspend fun toggleCommitmentDay(dateKey: String): Boolean {
        val existing = systemDao.getCommitmentDay(dateKey)
        return if (existing != null) {
            systemDao.deleteCommitmentDay(dateKey)
            false
        } else {
            systemDao.insertCommitmentDay(CommitmentDay(dateKey = dateKey, isCommitted = true))
            true
        }
    }

    suspend fun markCommitted(dateKey: String) {
        systemDao.insertCommitmentDay(CommitmentDay(dateKey = dateKey, isCommitted = true))
    }
}
