package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "Hunter",
    val isOnboarded: Boolean = false,
    val totalXp: Int = 0,
    val academicGoals: String = "Master Advanced Algorithms & Data Structures",
    val healthGoals: String = "Daily 45m workout, 8 hours sleep, clean hydration",
    val skillGoals: String = "Kotlin Jetpack Compose & System Architecture Mastery",
    val morningRoutine: String = "Hydrate, 10m Meditation, Morning Mobility Routine",
    val afternoonRoutine: String = "Deep Work Block (90m), Nutritious Lunch",
    val eveningRoutine: String = "Daily Review, Plan Next Day Quests, Screen-off at 10 PM",
    val exerciseRoutine: String = "100 Push-ups, 100 Squats, 5km Run / Calisthenics",
    val yearlyGoal: String = "Reach S-Rank Hunter Status & Ship Top Tier Project",
    val monthlyGoal: String = "Complete 90% Daily Quests & 30-Day Commitment Streak",
    val soundEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
