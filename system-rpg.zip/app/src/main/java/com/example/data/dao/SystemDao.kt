package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.CommitmentDay
import com.example.data.entity.DailyQuest
import com.example.data.entity.UserProfile
import com.example.data.entity.XpLog
import kotlinx.coroutines.flow.Flow

@Dao
interface SystemDao {

    // --- User Profile ---
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfile(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfile)

    @Query("UPDATE user_profile SET totalXp = :newXp WHERE id = 1")
    suspend fun updateXp(newXp: Int)

    // --- Daily Quests ---
    @Query("SELECT * FROM daily_quests WHERE dateKey = :dateKey ORDER BY goalIndex ASC")
    fun getQuestsForDateFlow(dateKey: String): Flow<List<DailyQuest>>

    @Query("SELECT * FROM daily_quests WHERE dateKey = :dateKey ORDER BY goalIndex ASC")
    suspend fun getQuestsForDate(dateKey: String): List<DailyQuest>

    @Query("SELECT * FROM daily_quests ORDER BY dateKey DESC")
    fun getAllQuestsFlow(): Flow<List<DailyQuest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuests(quests: List<DailyQuest>)

    @Update
    suspend fun updateQuest(quest: DailyQuest)

    @Query("UPDATE daily_quests SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun setQuestCompleted(id: Long, isCompleted: Boolean)

    @Query("UPDATE daily_quests SET title = :title, category = :category WHERE id = :id")
    suspend fun updateQuestContent(id: Long, title: String, category: String)

    @Query("SELECT COUNT(*) FROM daily_quests WHERE isCompleted = 1")
    fun getTotalCompletedQuestsCountFlow(): Flow<Int>

    // Category completed counts for radar
    @Query("SELECT COUNT(*) FROM daily_quests WHERE category = :category AND isCompleted = 1")
    fun getCompletedCountForCategoryFlow(category: String): Flow<Int>

    // --- Commitment Days ---
    @Query("SELECT * FROM commitment_days")
    fun getAllCommitmentDaysFlow(): Flow<List<CommitmentDay>>

    @Query("SELECT * FROM commitment_days WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getCommitmentDay(dateKey: String): CommitmentDay?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommitmentDay(day: CommitmentDay)

    @Query("DELETE FROM commitment_days WHERE dateKey = :dateKey")
    suspend fun deleteCommitmentDay(dateKey: String)

    // --- XP Logs ---
    @Query("SELECT * FROM xp_logs ORDER BY timestamp ASC")
    fun getAllXpLogsFlow(): Flow<List<XpLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertXpLog(log: XpLog)
}
