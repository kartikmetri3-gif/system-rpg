package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_quests")
data class DailyQuest(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateKey: String, // e.g. "2026-08-18"
    val goalIndex: Int,  // 0, 1, 2
    val title: String,
    val category: String = "ACADEMICS", // ACADEMICS, HEALTH, SKILLS
    val isCompleted: Boolean = false,
    val xpValue: Int = 33
)
