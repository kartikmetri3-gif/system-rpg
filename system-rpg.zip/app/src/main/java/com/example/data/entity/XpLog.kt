package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "xp_logs")
data class XpLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateKey: String,
    val xpEarned: Int,
    val totalXpAfter: Int,
    val reason: String = "DAILY_QUEST",
    val timestamp: Long = System.currentTimeMillis()
)
