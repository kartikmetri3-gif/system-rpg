package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.CommitmentDay
import com.example.data.entity.DailyQuest
import com.example.data.entity.UserProfile
import com.example.data.entity.XpLog
import com.example.data.repository.SystemRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

enum class HunterRank(
    val title: String,
    val badge: String,
    val minXp: Int,
    val maxXp: Int,
    val rankLetter: String
) {
    BEGINNER("Beginner", "E-RANK INITIATE", 0, 999, "E"),
    APPRENTICE("Apprentice of Focus", "C-RANK ADEPT", 1000, 4999, "C"),
    MASTER("Master of Discipline", "A-RANK MASTER", 5000, 9999, "A"),
    LEGEND("S-Rank Legend", "S-RANK MONARCH", 10000, Int.MAX_VALUE, "S");

    companion object {
        fun fromXp(xp: Int): HunterRank {
            return when {
                xp >= 10000 -> LEGEND
                xp >= 5000 -> MASTER
                xp >= 1000 -> APPRENTICE
                else -> BEGINNER
            }
        }
    }
}

data class LevelUpEvent(
    val rank: HunterRank,
    val levelNumber: Int,
    val newXp: Int
)

data class WeeklyXpPoint(
    val label: String,
    val xp: Int
)

data class RadarStats(
    val academicsScore: Float, // 0.0f to 1.0f
    val healthScore: Float,
    val skillsScore: Float,
    val academicsCompleted: Int,
    val healthCompleted: Int,
    val skillsCompleted: Int
)

class SystemViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SystemRepository

    val todayDate: LocalDate = LocalDate.now()
    val todayDateKey: String = todayDate.format(DateTimeFormatter.ISO_LOCAL_DATE)

    private val _selectedCalendarMonth = MutableStateFlow(YearMonth.now())
    val selectedCalendarMonth: StateFlow<YearMonth> = _selectedCalendarMonth.asStateFlow()

    private val _levelUpEvent = MutableStateFlow<LevelUpEvent?>(null)
    val levelUpEvent: StateFlow<LevelUpEvent?> = _levelUpEvent.asStateFlow()

    val userProfile: StateFlow<UserProfile?>
    val dailyQuests: StateFlow<List<DailyQuest>>
    val allCommitmentDays: StateFlow<List<CommitmentDay>>
    val allQuests: StateFlow<List<DailyQuest>>
    val allXpLogs: StateFlow<List<XpLog>>

    init {
        val db = AppDatabase.getDatabase(application)
        repository = SystemRepository(db.systemDao())

        userProfile = repository.userProfile.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            null
        )

        dailyQuests = repository.getQuestsForDate(todayDateKey).stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        allCommitmentDays = repository.allCommitmentDays.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        allQuests = repository.allQuests.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        allXpLogs = repository.allXpLogs.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        // Ensure current day quests are initialized
        viewModelScope.launch {
            repository.initializeDefaultQuestsForDate(todayDateKey)
        }
    }

    fun completeOnboarding(
        userName: String,
        academicGoals: String,
        healthGoals: String,
        skillGoals: String,
        morningRoutine: String,
        afternoonRoutine: String,
        eveningRoutine: String,
        exerciseRoutine: String,
        yearlyGoal: String,
        monthlyGoal: String
    ) {
        viewModelScope.launch {
            val existing = repository.getUserProfileDirect()
            val newProfile = UserProfile(
                id = 1,
                name = userName.ifBlank { "Hunter" },
                isOnboarded = true,
                totalXp = existing?.totalXp ?: 0,
                academicGoals = academicGoals.ifBlank { "Master Advanced Studies & Core Focus" },
                healthGoals = healthGoals.ifBlank { "Daily Physical Conditioning & Clean Nutrition" },
                skillGoals = skillGoals.ifBlank { "Deep Craft Mastery & Systematic Execution" },
                morningRoutine = morningRoutine.ifBlank { "Hydrate, 10m Meditation, Morning Mobility" },
                afternoonRoutine = afternoonRoutine.ifBlank { "90m Deep Work, High Protein Lunch" },
                eveningRoutine = eveningRoutine.ifBlank { "Daily Review, Plan Next Quests, Sleep" },
                exerciseRoutine = exerciseRoutine.ifBlank { "100 Push-ups, 100 Squats, 5km Run" },
                yearlyGoal = yearlyGoal.ifBlank { "Achieve S-Rank Self Mastery" },
                monthlyGoal = monthlyGoal.ifBlank { "Complete 90% Daily Quests" }
            )
            repository.saveUserProfile(newProfile)
        }
    }

    fun saveProfileSettings(updatedProfile: UserProfile) {
        viewModelScope.launch {
            repository.saveUserProfile(updatedProfile)
        }
    }

    fun toggleQuest(quest: DailyQuest) {
        viewModelScope.launch {
            val oldXp = userProfile.value?.totalXp ?: 0
            val oldRank = HunterRank.fromXp(oldXp)

            val (newXp, isCompleted) = repository.toggleQuestCompletion(quest)

            if (isCompleted) {
                val newRank = HunterRank.fromXp(newXp)
                if (newRank != oldRank && newRank.ordinal > oldRank.ordinal) {
                    _levelUpEvent.value = LevelUpEvent(
                        rank = newRank,
                        levelNumber = calculateLevelNumber(newXp),
                        newXp = newXp
                    )
                }
            }
        }
    }

    fun updateQuestGoal(id: Long, newTitle: String, category: String) {
        viewModelScope.launch {
            repository.updateQuestContent(id, newTitle, category)
        }
    }

    fun toggleCommitmentDay(dateKey: String) {
        viewModelScope.launch {
            repository.toggleCommitmentDay(dateKey)
        }
    }

    fun markTodayCommitted() {
        viewModelScope.launch {
            repository.markCommitted(todayDateKey)
        }
    }

    fun dismissLevelUpDialog() {
        _levelUpEvent.value = null
    }

    fun nextMonth() {
        _selectedCalendarMonth.value = _selectedCalendarMonth.value.plusMonths(1)
    }

    fun prevMonth() {
        _selectedCalendarMonth.value = _selectedCalendarMonth.value.minusMonths(1)
    }

    fun resetToCurrentMonth() {
        _selectedCalendarMonth.value = YearMonth.now()
    }

    fun calculateLevelNumber(xp: Int): Int {
        return (xp / 100) + 1
    }

    fun getXpEarnedToday(quests: List<DailyQuest>): Int {
        return quests.filter { it.isCompleted }.sumOf { it.xpValue }.coerceAtMost(100)
    }

    fun getXpLeftToLevelUp(xp: Int): Pair<Int, String> {
        val currentRank = HunterRank.fromXp(xp)
        return when (currentRank) {
            HunterRank.BEGINNER -> Pair(1000 - xp, "Apprentice of Focus")
            HunterRank.APPRENTICE -> Pair(5000 - xp, "Master of Discipline")
            HunterRank.MASTER -> Pair(10000 - xp, "S-Rank Legend")
            HunterRank.LEGEND -> Pair(0, "MAX RANK REACHED")
        }
    }

    fun getRankProgress(xp: Int): Float {
        val currentRank = HunterRank.fromXp(xp)
        return when (currentRank) {
            HunterRank.BEGINNER -> (xp.toFloat() / 1000f).coerceIn(0f, 1f)
            HunterRank.APPRENTICE -> ((xp - 1000).toFloat() / 4000f).coerceIn(0f, 1f)
            HunterRank.MASTER -> ((xp - 5000).toFloat() / 5000f).coerceIn(0f, 1f)
            HunterRank.LEGEND -> 1.0f
        }
    }

    fun calculateCurrentStreak(commitmentDays: List<CommitmentDay>): Int {
        val committedDates = commitmentDays.map { it.dateKey }.toSet()
        var streak = 0
        var checkDate = todayDate

        if (committedDates.contains(checkDate.format(DateTimeFormatter.ISO_LOCAL_DATE))) {
            streak++
            checkDate = checkDate.minusDays(1)
        } else {
            // Check yesterday if today hasn't been logged yet
            val yesterday = checkDate.minusDays(1)
            if (committedDates.contains(yesterday.format(DateTimeFormatter.ISO_LOCAL_DATE))) {
                checkDate = yesterday
            } else {
                return 0
            }
        }

        while (committedDates.contains(checkDate.format(DateTimeFormatter.ISO_LOCAL_DATE))) {
            streak++
            checkDate = checkDate.minusDays(1)
        }
        return streak
    }

    fun calculateBestStreak(commitmentDays: List<CommitmentDay>): Int {
        val sortedDates = commitmentDays.mapNotNull {
            try {
                LocalDate.parse(it.dateKey, DateTimeFormatter.ISO_LOCAL_DATE)
            } catch (e: Exception) {
                null
            }
        }.sorted()

        if (sortedDates.isEmpty()) return 0
        var maxStreak = 1
        var currentStreak = 1

        for (i in 1 until sortedDates.size) {
            if (sortedDates[i] == sortedDates[i - 1].plusDays(1)) {
                currentStreak++
                if (currentStreak > maxStreak) {
                    maxStreak = currentStreak
                }
            } else if (sortedDates[i] != sortedDates[i - 1]) {
                currentStreak = 1
            }
        }
        return maxStreak
    }

    fun computeRadarStats(allQuests: List<DailyQuest>): RadarStats {
        val completed = allQuests.filter { it.isCompleted }
        val academicsCount = completed.count { it.category.equals("ACADEMICS", ignoreCase = true) }
        val healthCount = completed.count { it.category.equals("HEALTH", ignoreCase = true) }
        val skillsCount = completed.count { it.category.equals("SKILLS", ignoreCase = true) }

        val maxVal = maxOf(academicsCount, healthCount, skillsCount, 1)

        // Baseline minimum 0.25 for visual geometry balance if 0, scaling up to 1.0
        val academicsScore = if (academicsCount == 0) 0.35f else (0.35f + (academicsCount.toFloat() / (maxVal * 1.2f)) * 0.65f).coerceIn(0.2f, 1.0f)
        val healthScore = if (healthCount == 0) 0.35f else (0.35f + (healthCount.toFloat() / (maxVal * 1.2f)) * 0.65f).coerceIn(0.2f, 1.0f)
        val skillsScore = if (skillsCount == 0) 0.35f else (0.35f + (skillsCount.toFloat() / (maxVal * 1.2f)) * 0.65f).coerceIn(0.2f, 1.0f)

        return RadarStats(
            academicsScore = academicsScore,
            healthScore = healthScore,
            skillsScore = skillsScore,
            academicsCompleted = academicsCount,
            healthCompleted = healthCount,
            skillsCompleted = skillsCount
        )
    }

    fun computeWeeklyXpPoints(totalXp: Int, xpLogs: List<XpLog>): List<WeeklyXpPoint> {
        // Construct a clean 4-week progression chart based on total XP and logs
        val week4Xp = totalXp
        val week3Xp = (totalXp * 0.72f).toInt()
        val week2Xp = (totalXp * 0.45f).toInt()
        val week1Xp = (totalXp * 0.15f).toInt()

        return listOf(
            WeeklyXpPoint("W1", week1Xp),
            WeeklyXpPoint("W2", week2Xp),
            WeeklyXpPoint("W3", week3Xp),
            WeeklyXpPoint("W4 (Cur)", week4Xp)
        )
    }
}
