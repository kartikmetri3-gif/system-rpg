package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.WeeklyXpPoint

@Composable
fun SystemXpLineChart(
    points: List<WeeklyXpPoint>,
    totalXp: Int,
    modifier: Modifier = Modifier
) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(points) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing)
        )
    }

    val textMeasurer = rememberTextMeasurer()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SystemCardBg, RoundedCornerShape(16.dp))
            .border(1.dp, SystemCardBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(CyberNeonGreen, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "XP PROGRESS TRAJECTORY",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            Text(
                text = "$totalXp TOTAL XP",
                color = CyberGold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = "Y-Axis: Total Experience | X-Axis: Weekly Growth",
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val paddingLeft = 45.dp.toPx()
                val paddingBottom = 26.dp.toPx()
                val paddingTop = 12.dp.toPx()
                val paddingRight = 20.dp.toPx()

                val chartWidth = size.width - paddingLeft - paddingRight
                val chartHeight = size.height - paddingTop - paddingBottom

                val maxYVal = maxOf(points.maxOfOrNull { it.xp } ?: 100, 100).let {
                    // Round up to nice number
                    val magnitude = when {
                        it <= 100 -> 100
                        it <= 500 -> 500
                        it <= 1000 -> 1000
                        it <= 5000 -> 5000
                        else -> ((it / 1000) + 1) * 1000
                    }
                    magnitude
                }

                // 1. Draw Horizontal Grid Lines and Y-Axis Labels
                val yStepCount = 4
                for (i in 0..yStepCount) {
                    val yFraction = i.toFloat() / yStepCount
                    val yPos = paddingTop + chartHeight * (1f - yFraction)
                    val yVal = (maxYVal * yFraction).toInt()

                    // Grid line
                    drawLine(
                        color = Color(0x26334155),
                        start = Offset(paddingLeft, yPos),
                        end = Offset(size.width - paddingRight, yPos),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )

                    // Y Label
                    val yTextLayout = textMeasurer.measure(
                        text = if (yVal >= 1000) "${yVal / 1000}k" else "$yVal",
                        style = TextStyle(
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    drawText(
                        textLayoutResult = yTextLayout,
                        topLeft = Offset(paddingLeft - yTextLayout.size.width - 6.dp.toPx(), yPos - yTextLayout.size.height / 2f)
                    )
                }

                // 2. Compute Points coordinates
                if (points.isNotEmpty()) {
                    val numPoints = points.size
                    val stepX = if (numPoints > 1) chartWidth / (numPoints - 1) else chartWidth

                    val offsets = points.mapIndexed { index, pt ->
                        val x = paddingLeft + index * stepX
                        val normalizedY = (pt.xp.toFloat() / maxYVal).coerceIn(0f, 1f) * animProgress.value
                        val y = paddingTop + chartHeight * (1f - normalizedY)
                        Offset(x, y)
                    }

                    // 3. Draw Gradient Area under Line
                    val fillPath = Path().apply {
                        moveTo(offsets.first().x, paddingTop + chartHeight)
                        offsets.forEach { lineTo(it.x, it.y) }
                        lineTo(offsets.last().x, paddingTop + chartHeight)
                        close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0x5900E5FF),
                                Color(0x2000FF88),
                                Color(0x000A0A0A)
                            ),
                            startY = paddingTop,
                            endY = paddingTop + chartHeight
                        )
                    )

                    // 4. Draw Line Stroke
                    val linePath = Path().apply {
                        offsets.forEachIndexed { i, off ->
                            if (i == 0) moveTo(off.x, off.y) else lineTo(off.x, off.y)
                        }
                    }

                    drawPath(
                        path = linePath,
                        brush = Brush.horizontalGradient(
                            colors = listOf(CyberNeonBlue, CyberNeonGreen)
                        ),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // 5. Draw Point Nodes and X-Axis Labels
                    offsets.forEachIndexed { i, off ->
                        // Glow circle
                        drawCircle(
                            color = Color(0x6600E5FF),
                            radius = 6.dp.toPx(),
                            center = off
                        )
                        drawCircle(
                            color = CyberNeonGreen,
                            radius = 4.dp.toPx(),
                            center = off
                        )
                        drawCircle(
                            color = Color.Black,
                            radius = 2.dp.toPx(),
                            center = off
                        )

                        // X-Axis Label
                        val xTextLayout = textMeasurer.measure(
                            text = points[i].label,
                            style = TextStyle(
                                color = if (i == points.lastIndex) CyberNeonGreen else TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (i == points.lastIndex) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                        drawText(
                            textLayoutResult = xTextLayout,
                            topLeft = Offset(
                                off.x - xTextLayout.size.width / 2f,
                                paddingTop + chartHeight + 6.dp.toPx()
                            )
                        )
                    }
                }
            }
        }
    }
}
