package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.UserProfile
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.SystemViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: SystemViewModel,
    profile: UserProfile?,
    onRestartOnboarding: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var userName by remember(profile) { mutableStateOf(profile?.name ?: "Hunter") }
    var academicGoals by remember(profile) { mutableStateOf(profile?.academicGoals ?: "") }
    var healthGoals by remember(profile) { mutableStateOf(profile?.healthGoals ?: "") }
    var skillGoals by remember(profile) { mutableStateOf(profile?.skillGoals ?: "") }
    var morningRoutine by remember(profile) { mutableStateOf(profile?.morningRoutine ?: "") }
    var afternoonRoutine by remember(profile) { mutableStateOf(profile?.afternoonRoutine ?: "") }
    var eveningRoutine by remember(profile) { mutableStateOf(profile?.eveningRoutine ?: "") }
    var exerciseRoutine by remember(profile) { mutableStateOf(profile?.exerciseRoutine ?: "") }
    var yearlyGoal by remember(profile) { mutableStateOf(profile?.yearlyGoal ?: "") }
    var monthlyGoal by remember(profile) { mutableStateOf(profile?.monthlyGoal ?: "") }

    var saveSuccess by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(SystemBg)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Screen Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = CyberNeonGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SYSTEM CONFIGURATION",
                                color = CyberNeonGreen,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(
                            text = "EDIT SYSTEM PROTOCOLS",
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val updated = (profile ?: UserProfile()).copy(
                                name = userName,
                                academicGoals = academicGoals,
                                healthGoals = healthGoals,
                                skillGoals = skillGoals,
                                morningRoutine = morningRoutine,
                                afternoonRoutine = afternoonRoutine,
                                eveningRoutine = eveningRoutine,
                                exerciseRoutine = exerciseRoutine,
                                yearlyGoal = yearlyGoal,
                                monthlyGoal = monthlyGoal
                            )
                            viewModel.saveProfileSettings(updated)
                            saveSuccess = true
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("System Parameters Successfully Re-Calibrated!")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberNeonGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("save_system_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SAVE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // 1. Hunter Identifier
            item {
                SettingsSectionCard(
                    title = "HUNTER IDENTITY",
                    icon = Icons.Default.Person,
                    accentColor = CyberNeonBlue
                ) {
                    SettingsField(
                        label = "Hunter Name",
                        value = userName,
                        onValueChange = { userName = it },
                        accentColor = CyberNeonBlue
                    )
                }
            }

            // 2. Core Domain Goals
            item {
                SettingsSectionCard(
                    title = "CORE DOMAIN GOALS",
                    icon = Icons.Default.School,
                    accentColor = CyberNeonBlue
                ) {
                    SettingsField(
                        label = "Academic Goals",
                        value = academicGoals,
                        onValueChange = { academicGoals = it },
                        accentColor = CyberNeonBlue,
                        minLines = 2
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsField(
                        label = "Health Goals",
                        value = healthGoals,
                        onValueChange = { healthGoals = it },
                        accentColor = CyberNeonGreen,
                        minLines = 2
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsField(
                        label = "Skill Goals",
                        value = skillGoals,
                        onValueChange = { skillGoals = it },
                        accentColor = CyberNeonPurple,
                        minLines = 2
                    )
                }
            }

            // 3. Daily Routines
            item {
                SettingsSectionCard(
                    title = "DAILY PROTOCOLS & ROUTINES",
                    icon = Icons.Default.Tune,
                    accentColor = CyberGold
                ) {
                    SettingsField(
                        label = "Morning Routine",
                        value = morningRoutine,
                        onValueChange = { morningRoutine = it },
                        accentColor = CyberNeonBlue,
                        minLines = 2
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsField(
                        label = "Afternoon Routine",
                        value = afternoonRoutine,
                        onValueChange = { afternoonRoutine = it },
                        accentColor = CyberGold,
                        minLines = 2
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsField(
                        label = "Evening Routine",
                        value = eveningRoutine,
                        onValueChange = { eveningRoutine = it },
                        accentColor = CyberNeonPurple,
                        minLines = 2
                    )
                }
            }

            // 4. Exercise Routine
            item {
                SettingsSectionCard(
                    title = "EXERCISE PROTOCOL",
                    icon = Icons.Default.FitnessCenter,
                    accentColor = CyberNeonGreen
                ) {
                    SettingsField(
                        label = "Exercise Routine",
                        value = exerciseRoutine,
                        onValueChange = { exerciseRoutine = it },
                        accentColor = CyberNeonGreen,
                        minLines = 3
                    )
                }
            }

            // 5. Strategic Long-Term Horizons
            item {
                SettingsSectionCard(
                    title = "STRATEGIC GOAL HORIZONS",
                    icon = Icons.Default.Flag,
                    accentColor = CyberGold
                ) {
                    SettingsField(
                        label = "Yearly Goal",
                        value = yearlyGoal,
                        onValueChange = { yearlyGoal = it },
                        accentColor = CyberGold,
                        minLines = 2
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsField(
                        label = "Monthly Goal",
                        value = monthlyGoal,
                        onValueChange = { monthlyGoal = it },
                        accentColor = CyberNeonBlue,
                        minLines = 2
                    )
                }
            }

            // 6. System Reset / Re-Onboard Action
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SystemCardBg),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "SYSTEM INITIALIZATION WIZARD",
                            color = TextWhite,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Re-launch the 5-step interactive awakening terminal flow to recalibrate your entire profile from scratch.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.SansSerif
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = onRestartOnboarding,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberNeonBlue.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Restart",
                                tint = CyberNeonBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "RE-RUN ONBOARDING FLOW",
                                color = CyberNeonBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SystemCardBg),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = TextWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun SettingsField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    accentColor: Color,
    minLines: Int = 1
) {
    Column {
        Text(
            text = label.uppercase(),
            color = accentColor,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            minLines = minLines,
            maxLines = minLines + 2,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0F141C),
                unfocusedContainerColor = Color(0xFF0F141C),
                focusedBorderColor = accentColor,
                unfocusedBorderColor = SystemCardBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            ),
            shape = RoundedCornerShape(8.dp)
        )
    }
}
