package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.DailyQuest
import com.example.data.entity.UserProfile
import com.example.ui.components.SystemHeader
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPurple
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.HunterRank
import com.example.viewmodel.SystemViewModel

@Composable
fun DashboardScreen(
    viewModel: SystemViewModel,
    profile: UserProfile?,
    dailyQuests: List<DailyQuest>,
    modifier: Modifier = Modifier
) {
    val totalXp = profile?.totalXp ?: 0
    val levelNumber = viewModel.calculateLevelNumber(totalXp)
    val rank = HunterRank.fromXp(totalXp)
    val rankProgress = viewModel.getRankProgress(totalXp)

    val xpEarnedToday = viewModel.getXpEarnedToday(dailyQuests)
    val (xpLeft, nextRankTitle) = viewModel.getXpLeftToLevelUp(totalXp)

    var editingQuest by remember { mutableStateOf<DailyQuest?>(null) }
    var showRoutinesExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // 1. Header with Current Date & User Name prominently
            SystemHeader(
                userName = profile?.name ?: "Hunter",
                totalXp = totalXp,
                levelNumber = levelNumber,
                date = viewModel.todayDate,
                modifier = Modifier.testTag("dashboard_header")
            )
        }

        item {
            // 2. XP Status & Leveling Bar Card
            XpStatusBarCard(
                xpEarnedToday = xpEarnedToday,
                xpLeft = xpLeft,
                nextRankTitle = nextRankTitle,
                rank = rank,
                totalXp = totalXp,
                rankProgress = rankProgress
            )
        }

        item {
            // 3. Daily Main Quests Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(CyberNeonBlue, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MAIN GOALS OF THE DAY",
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "${dailyQuests.count { it.isCompleted }}/3 COMPLETE",
                    color = if (dailyQuests.all { it.isCompleted } && dailyQuests.isNotEmpty()) CyberNeonGreen else CyberNeonBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 3 Input Fields / Quest Slots for Main Goals of the Day
        items(dailyQuests.size) { index ->
            val quest = dailyQuests[index]
            DailyQuestItemCard(
                quest = quest,
                goalSlot = index + 1,
                onToggle = { viewModel.toggleQuest(quest) },
                onEdit = { editingQuest = quest }
            )
        }

        item {
            // 4. Daily Routines Quick Protocol Section
            DailyRoutinesAccordion(
                profile = profile,
                isExpanded = showRoutinesExpanded,
                onToggleExpand = { showRoutinesExpanded = !showRoutinesExpanded }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Edit Quest Dialog
    editingQuest?.let { quest ->
        EditGoalDialog(
            quest = quest,
            onDismiss = { editingQuest = null },
            onSave = { newTitle, newCategory ->
                viewModel.updateQuestGoal(quest.id, newTitle, newCategory)
                editingQuest = null
            }
        )
    }
}

@Composable
private fun XpStatusBarCard(
    xpEarnedToday: Int,
    xpLeft: Int,
    nextRankTitle: String,
    rank: HunterRank,
    totalXp: Int,
    rankProgress: Float
) {
    val animatedProgress by animateFloatAsState(
        targetValue = rankProgress,
        animationSpec = tween(durationMillis = 600),
        label = "rankProgress"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("xp_status_bar"),
        colors = CardDefaults.cardColors(containerColor = SystemCardBg),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Status Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "XP EARNED TODAY",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "+$xpEarnedToday / 100 XP",
                        color = CyberNeonGreen,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "XP LEFT TO LEVEL UP",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = if (xpLeft > 0) "$xpLeft XP" else "MAX REACHED",
                        color = CyberNeonBlue,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Level Progress Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Current: ${rank.title}",
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (rank != HunterRank.LEGEND) "Next: $nextRankTitle" else "S-Rank Sovereign",
                        color = CyberGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xFF0F141D))
                ) {
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier.fillMaxSize(),
                        color = CyberNeonBlue,
                        trackColor = Color.Transparent,
                        strokeCap = StrokeCap.Round
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "$totalXp Total XP",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${(animatedProgress * 100).toInt()}%",
                        color = CyberNeonBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun DailyQuestItemCard(
    quest: DailyQuest,
    goalIndex: Int = quest.goalIndex,
    goalSlot: Int,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    val categoryColor = when (quest.category.uppercase()) {
        "ACADEMICS" -> CyberNeonBlue
        "HEALTH" -> CyberNeonGreen
        "SKILLS" -> CyberNeonPurple
        else -> CyberNeonBlue
    }

    val checkboxBg by animateColorAsState(
        targetValue = if (quest.isCompleted) categoryColor else Color.Transparent,
        label = "cbBg"
    )

    val borderPulse by animateColorAsState(
        targetValue = if (quest.isCompleted) categoryColor.copy(alpha = 0.5f) else SystemCardBorder,
        label = "border"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .testTag("quest_card_${quest.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (quest.isCompleted) Color(0xFF131A24) else SystemCardBg
        ),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderPulse)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox with Neon Glow
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(checkboxBg)
                    .border(
                        width = 2.dp,
                        color = if (quest.isCompleted) categoryColor else Color(0xFF334155),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { onToggle() }
                    .testTag("quest_checkbox_${quest.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (quest.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Quest Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "GOAL #$goalSlot [${quest.category.uppercase()}]",
                        color = categoryColor,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "+${quest.xpValue} XP",
                        color = CyberGold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = quest.title,
                    color = if (quest.isCompleted) TextMuted else TextWhite,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium,
                    textDecoration = if (quest.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
            }

            // Edit button
            IconButton(
                onClick = onEdit,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Goal",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun DailyRoutinesAccordion(
    profile: UserProfile?,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("routines_accordion"),
        colors = CardDefaults.cardColors(containerColor = SystemCardBg),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Routines",
                        tint = CyberNeonGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SYSTEM ROUTINES & PROTOCOLS",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(onClick = onToggleExpand, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Expand",
                        tint = CyberNeonGreen
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RoutineItemRow(
                        title = "Morning Routine",
                        content = profile?.morningRoutine ?: "Hydrate, 10m Meditation, Morning Mobility",
                        icon = Icons.Default.WbSunny,
                        iconColor = CyberNeonBlue
                    )
                    RoutineItemRow(
                        title = "Afternoon Routine",
                        content = profile?.afternoonRoutine ?: "90m Deep Work, High Protein Lunch",
                        icon = Icons.Default.WbTwilight,
                        iconColor = CyberGold
                    )
                    RoutineItemRow(
                        title = "Evening Routine",
                        content = profile?.eveningRoutine ?: "Daily Review, Plan Next Quests, Sleep",
                        icon = Icons.Default.NightlightRound,
                        iconColor = CyberNeonPurple
                    )
                    RoutineItemRow(
                        title = "Exercise Routine",
                        content = profile?.exerciseRoutine ?: "100 Push-ups, 100 Squats, 5km Run",
                        icon = Icons.Default.FitnessCenter,
                        iconColor = CyberNeonGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun RoutineItemRow(
    title: String,
    content: String,
    icon: ImageVector,
    iconColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F141C), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = iconColor,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title.uppercase(),
                color = iconColor,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = content,
                color = TextWhite,
                fontSize = 13.sp,
                fontFamily = FontFamily.SansSerif
            )
        }
    }
}

@Composable
private fun EditGoalDialog(
    quest: DailyQuest,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var title by remember { mutableStateOf(quest.title) }
    var selectedCategory by remember { mutableStateOf(quest.category) }

    val categories = listOf("ACADEMICS", "HEALTH", "SKILLS")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SystemCardBg,
        title = {
            Text(
                text = "EDIT DAILY GOAL",
                color = CyberNeonBlue,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "Goal Title",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0F141C),
                        unfocusedContainerColor = Color(0xFF0F141C),
                        focusedBorderColor = CyberNeonBlue,
                        unfocusedBorderColor = SystemCardBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "System Category",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedCategory.equals(cat, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CyberNeonBlue.copy(alpha = 0.2f) else Color(0xFF0F141C))
                                .border(
                                    1.dp,
                                    if (isSelected) CyberNeonBlue else SystemCardBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { selectedCategory = cat }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) CyberNeonBlue else TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(title, selectedCategory) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberNeonBlue, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("SAVE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
            }
        }
    )
}
