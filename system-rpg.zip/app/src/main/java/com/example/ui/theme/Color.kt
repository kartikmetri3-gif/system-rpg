package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Deep High-Tech System Palette
val SystemBg = Color(0xFF0A0A0A)
val SystemSurface = Color(0xFF12161F)
val SystemCardBg = Color(0xFF161C26)
val SystemCardBorder = Color(0xFF1E293B)

// Neon & Cyber Accents
val CyberNeonBlue = Color(0xFF00E5FF)
val CyberNeonGreen = Color(0xFF00FF88)
val CyberNeonPurple = Color(0xFFBD00FF)
val CyberRed = Color(0xFFFF2A55)
val CyberGold = Color(0xFFFFB800)
val CyberOrange = Color(0xFFFF7A00)

// Text Colors
val TextWhite = Color(0xFFF0F6FC)
val TextMuted = Color(0xFF8B949E)
val TextDim = Color(0xFF484F58)
val TextCyberBlue = Color(0xFF70EFFF)
val TextCyberGreen = Color(0xFF7AFFBA)

// Glow & Translucents
val GlowCyan = Color(0x3300E5FF)
val GlowGreen = Color(0x3300FF88)
val GlowPurple = Color(0x33BD00FF)
val GlowRed = Color(0x33FF2A55)
val SurfaceHighlight = Color(0xFF1F2633)
