package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CommitmentDay
import com.example.data.entity.DailyQuest
import com.example.data.entity.UserProfile
import com.example.ui.components.SystemRadarChart
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPurple
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.HunterRank
import com.example.viewmodel.SystemViewModel

@Composable
fun ProfileScreen(
    viewModel: SystemViewModel,
    profile: UserProfile?,
    commitmentDays: List<CommitmentDay>,
    allQuests: List<DailyQuest>,
    modifier: Modifier = Modifier
) {
    val totalXp = profile?.totalXp ?: 0
    val levelNumber = viewModel.calculateLevelNumber(totalXp)
    val rank = HunterRank.fromXp(totalXp)
    val currentStreak = viewModel.calculateCurrentStreak(commitmentDays)
    val bestStreak = viewModel.calculateBestStreak(commitmentDays)
    val completedQuestsCount = allQuests.count { it.isCompleted }
    val radarStats = viewModel.computeRadarStats(allQuests)

    val rankAccentColor = when (rank) {
        HunterRank.BEGINNER -> CyberNeonBlue
        HunterRank.APPRENTICE -> CyberNeonGreen
        HunterRank.MASTER -> CyberNeonPurple
        HunterRank.LEGEND -> CyberGold
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile",
                            tint = CyberNeonBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "HUNTER STATUS INTERFACE",
                            color = CyberNeonBlue,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "PLAYER STATS & MATRIX",
                        color = TextWhite,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                        .border(1.dp, rankAccentColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = rank.badge,
                        color = rankAccentColor,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            // 1. High-Tech Player Status Window Card (Solo Leveling System HUD style)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("player_status_card"),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF101520)
                ),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.verticalGradient(
                        colors = listOf(rankAccentColor, SystemCardBorder)
                    )
                )
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // System Banner inside Card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "[STATUS WINDOW]",
                            color = CyberNeonBlue,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )

                        Text(
                            text = "CLASS: DISCIPLINE HUNTER",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Player Name and Rank Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Avatar Badge
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .background(rankAccentColor.copy(alpha = 0.15f), CircleShape)
                                .border(1.5.dp, rankAccentColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = rank.rankLetter,
                                color = rankAccentColor,
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = profile?.name ?: "Hunter",
                                color = TextWhite,
                                fontSize = 20.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = rank.title.uppercase(),
                                color = rankAccentColor,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 4 Grid Stats Matrix
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PlayerStatBox(
                            title = "CURRENT STREAK",
                            value = "$currentStreak Days",
                            icon = Icons.Default.LocalFireDepartment,
                            color = CyberOrange,
                            modifier = Modifier.weight(1f)
                        )
                        PlayerStatBox(
                            title = "BEST STREAK",
                            value = "$bestStreak Days",
                            icon = Icons.Default.EmojiEvents,
                            color = CyberGold,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PlayerStatBox(
                            title = "TOTAL XP",
                            value = "$totalXp XP",
                            icon = Icons.Default.Bolt,
                            color = CyberNeonBlue,
                            modifier = Modifier.weight(1f)
                        )
                        PlayerStatBox(
                            title = "SYSTEM LEVEL",
                            value = "Level $levelNumber",
                            icon = Icons.Default.Shield,
                            color = CyberNeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            // 2. Skills Web Radar Chart in Profile
            SystemRadarChart(
                stats = radarStats,
                modifier = Modifier.testTag("profile_radar_chart")
            )
        }

        item {
            // 3. Strategic Quest Directives (Yearly & Monthly Goals summary)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SystemCardBg),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "STRATEGIC SYSTEM DIRECTIVES",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GoalDirectiveRow(
                        title = "Yearly Master Quest",
                        content = profile?.yearlyGoal ?: "Attain S-Rank Self Mastery",
                        accentColor = CyberGold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    GoalDirectiveRow(
                        title = "Monthly Objective",
                        content = profile?.monthlyGoal ?: "90% Daily Quest Completion",
                        accentColor = CyberNeonBlue
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    GoalDirectiveRow(
                        title = "Academic Target",
                        content = profile?.academicGoals ?: "Master Advanced Studies",
                        accentColor = CyberNeonBlue
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    GoalDirectiveRow(
                        title = "Health Target",
                        content = profile?.healthGoals ?: "Physical Conditioning & Clean Nutrition",
                        accentColor = CyberNeonGreen
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    GoalDirectiveRow(
                        title = "Skill Target",
                        content = profile?.skillGoals ?: "Deep Craft Mastery",
                        accentColor = CyberNeonPurple
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PlayerStatBox(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF0C1017), RoundedCornerShape(12.dp))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                color = color,
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun GoalDirectiveRow(
    title: String,
    content: String,
    accentColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F141C), RoundedCornerShape(10.dp))
            .border(1.dp, SystemCardBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title.uppercase(),
                color = accentColor,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = content,
                color = TextWhite,
                fontSize = 13.sp,
                fontFamily = FontFamily.SansSerif
            )
        }
    }
}
