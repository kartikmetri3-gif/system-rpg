package com.example.ui.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.ElectricBolt
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.SystemLevelUpDialog
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.ChartsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.SystemViewModel

enum class SystemTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val activeColor: Color
) {
    QUESTS("Quests", Icons.Filled.ElectricBolt, Icons.Outlined.ElectricBolt, CyberNeonBlue),
    ANALYTICS("Analytics", Icons.Filled.BarChart, Icons.Outlined.BarChart, CyberNeonGreen),
    CALENDAR("Calendar", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, CyberRed),
    PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person, CyberNeonBlue),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, CyberNeonGreen)
}

@Composable
fun SystemAppContent(
    viewModel: SystemViewModel
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val dailyQuests by viewModel.dailyQuests.collectAsStateWithLifecycle()
    val allQuests by viewModel.allQuests.collectAsStateWithLifecycle()
    val commitmentDays by viewModel.allCommitmentDays.collectAsStateWithLifecycle()
    val allXpLogs by viewModel.allXpLogs.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedCalendarMonth.collectAsStateWithLifecycle()
    val levelUpEvent by viewModel.levelUpEvent.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(SystemTab.QUESTS) }
    var forceOnboarding by remember { mutableStateOf(false) }

    val showOnboarding = (profile == null || !profile!!.isOnboarded) || forceOnboarding

    if (showOnboarding) {
        OnboardingScreen(
            onComplete = { userName, academicGoals, healthGoals, skillGoals, morningRoutine, afternoonRoutine, eveningRoutine, exerciseRoutine, yearlyGoal, monthlyGoal ->
                viewModel.completeOnboarding(
                    userName = userName,
                    academicGoals = academicGoals,
                    healthGoals = healthGoals,
                    skillGoals = skillGoals,
                    morningRoutine = morningRoutine,
                    afternoonRoutine = afternoonRoutine,
                    eveningRoutine = eveningRoutine,
                    exerciseRoutine = exerciseRoutine,
                    yearlyGoal = yearlyGoal,
                    monthlyGoal = monthlyGoal
                )
                forceOnboarding = false
                activeTab = SystemTab.QUESTS
            }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = SystemBg,
            bottomBar = {
                SystemBottomNavigationBar(
                    activeTab = activeTab,
                    onTabSelected = { activeTab = it }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = activeTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tabSwitch"
                ) { tab ->
                    when (tab) {
                        SystemTab.QUESTS -> DashboardScreen(
                            viewModel = viewModel,
                            profile = profile,
                            dailyQuests = dailyQuests
                        )
                        SystemTab.ANALYTICS -> ChartsScreen(
                            viewModel = viewModel,
                            profile = profile,
                            allQuests = allQuests,
                            allXpLogs = allXpLogs
                        )
                        SystemTab.CALENDAR -> CalendarScreen(
                            viewModel = viewModel,
                            selectedMonth = selectedMonth,
                            commitmentDays = commitmentDays
                        )
                        SystemTab.PROFILE -> ProfileScreen(
                            viewModel = viewModel,
                            profile = profile,
                            commitmentDays = commitmentDays,
                            allQuests = allQuests
                        )
                        SystemTab.SETTINGS -> SettingsScreen(
                            viewModel = viewModel,
                            profile = profile,
                            onRestartOnboarding = { forceOnboarding = true }
                        )
                    }
                }

                // Level Up Event Alert Modal
                levelUpEvent?.let { event ->
                    SystemLevelUpDialog(
                        event = event,
                        onDismiss = { viewModel.dismissLevelUpDialog() }
                    )
                }
            }
        }
    }
}

@Composable
fun SystemBottomNavigationBar(
    activeTab: SystemTab,
    onTabSelected: (SystemTab) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SystemCardBorder)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("system_bottom_nav"),
        containerColor = SystemCardBg,
        tonalElevation = 8.dp
    ) {
        SystemTab.entries.forEach { tab ->
            val isSelected = tab == activeTab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = tab.title,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = tab.title.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = tab.activeColor,
                    selectedTextColor = tab.activeColor,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted,
                    indicatorColor = tab.activeColor.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
