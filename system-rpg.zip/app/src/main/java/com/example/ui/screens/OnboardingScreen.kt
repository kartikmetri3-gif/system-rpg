package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPurple
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun OnboardingScreen(
    onComplete: (
        userName: String,
        academicGoals: String,
        healthGoals: String,
        skillGoals: String,
        morningRoutine: String,
        afternoonRoutine: String,
        eveningRoutine: String,
        exerciseRoutine: String,
        yearlyGoal: String,
        monthlyGoal: String
    ) -> Unit
) {
    var currentStep by remember { mutableIntStateOf(1) }

    // Step 1: Goals
    var academicGoals by remember { mutableStateOf("Complete 2 hours deep focus study daily & master core course") }
    var healthGoals by remember { mutableStateOf("Maintain 8 hours sleep, 3L water hydration & nutritious fuel") }
    var skillGoals by remember { mutableStateOf("Build 1 functional project & practice coding daily") }

    // Step 2: Daily Routines
    var morningRoutine by remember { mutableStateOf("Cold shower, hydrate, 10m meditation, plan top 3 priorities") }
    var afternoonRoutine by remember { mutableStateOf("90m deep work block, healthy meal, 15m walk") }
    var eveningRoutine by remember { mutableStateOf("Daily quest review, log XP, 0 screens after 10 PM") }

    // Step 3: Exercise Routine
    var exerciseRoutine by remember { mutableStateOf("100 pushups, 100 squats, 5km cardio or 45m strength session") }

    // Step 4: Long-Term Goals
    var yearlyGoal by remember { mutableStateOf("Attain S-Rank Hunter status & achieve financial & physical mastery") }
    var monthlyGoal by remember { mutableStateOf("Maintain a 30-day streak & complete 90% of daily quests") }

    // Step 5: User Name
    var userName by remember { mutableStateOf("Hunter") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SystemBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // System Terminal Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "System",
                    tint = CyberNeonBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SYSTEM INITIALIZATION PROTOCOL",
                    color = CyberNeonBlue,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "AWAKENING SEQUENCE",
                color = TextWhite,
                fontSize = 22.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 5-Step Progress Indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (step in 1..5) {
                    val isActive = step == currentStep
                    val isPassed = step < currentStep
                    val stepColor = when {
                        isActive -> CyberNeonBlue
                        isPassed -> CyberNeonGreen
                        else -> SystemCardBorder
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(
                                color = if (isActive || isPassed) stepColor.copy(alpha = 0.15f) else Color.Transparent,
                                shape = CircleShape
                            )
                            .border(
                                width = if (isActive) 2.dp else 1.dp,
                                color = stepColor,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isPassed) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Done",
                                tint = CyberNeonGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        } else {
                            Text(
                                text = "$step",
                                color = if (isActive) CyberNeonBlue else TextMuted,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (step < 5) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(2.dp)
                                .background(
                                    if (step < currentStep) CyberNeonGreen else SystemCardBorder
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Dynamic Step Content Card
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> -width } + fadeOut())
                    } else {
                        (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> width } + fadeOut())
                    }
                },
                label = "stepAnimation"
            ) { step ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SystemCardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, SystemCardBorder, RoundedCornerShape(16.dp))
                        .padding(20.dp)
                ) {
                    when (step) {
                        1 -> Step1Goals(
                            academicGoals = academicGoals,
                            onAcademicChange = { academicGoals = it },
                            healthGoals = healthGoals,
                            onHealthChange = { healthGoals = it },
                            skillGoals = skillGoals,
                            onSkillChange = { skillGoals = it }
                        )
                        2 -> Step2Routines(
                            morning = morningRoutine,
                            onMorningChange = { morningRoutine = it },
                            afternoon = afternoonRoutine,
                            onAfternoonChange = { afternoonRoutine = it },
                            evening = eveningRoutine,
                            onEveningChange = { eveningRoutine = it }
                        )
                        3 -> Step3Exercise(
                            exercise = exerciseRoutine,
                            onExerciseChange = { exerciseRoutine = it }
                        )
                        4 -> Step4LongTerm(
                            yearly = yearlyGoal,
                            onYearlyChange = { yearlyGoal = it },
                            monthly = monthlyGoal,
                            onMonthlyChange = { monthlyGoal = it }
                        )
                        5 -> Step5User(
                            userName = userName,
                            onUserNameChange = { userName = it }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Navigation Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 1) {
                    Button(
                        onClick = { currentStep-- },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E2638),
                            contentColor = TextWhite
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PREVIOUS",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (currentStep < 5) {
                    Button(
                        onClick = { currentStep++ },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberNeonBlue,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text(
                            text = "NEXT PHASE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Button(
                        onClick = {
                            onComplete(
                                userName,
                                academicGoals,
                                healthGoals,
                                skillGoals,
                                morningRoutine,
                                afternoonRoutine,
                                eveningRoutine,
                                exerciseRoutine,
                                yearlyGoal,
                                monthlyGoal
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberNeonGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth(if (currentStep > 1) 0.65f else 1f)
                            .height(50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Awaken",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "INITIALIZE SYSTEM",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StepHeader(title: String, subtitle: String, icon: ImageVector, accentColor: Color) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title.uppercase(),
                color = TextWhite,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            color = TextMuted,
            fontSize = 12.sp,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SystemInputField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    accentColor: Color = CyberNeonBlue,
    minLines: Int = 1
) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(
            text = label.uppercase(),
            color = accentColor,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextMuted.copy(alpha = 0.6f), fontSize = 13.sp) },
            modifier = Modifier.fillMaxWidth(),
            minLines = minLines,
            maxLines = minLines + 2,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0F141C),
                unfocusedContainerColor = Color(0xFF0F141C),
                focusedBorderColor = accentColor,
                unfocusedBorderColor = SystemCardBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            ),
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
private fun Step1Goals(
    academicGoals: String,
    onAcademicChange: (String) -> Unit,
    healthGoals: String,
    onHealthChange: (String) -> Unit,
    skillGoals: String,
    onSkillChange: (String) -> Unit
) {
    Column {
        StepHeader(
            title = "Step 1: Core Domain Goals",
            subtitle = "Define your foundation across the three System Pillars.",
            icon = Icons.Default.School,
            accentColor = CyberNeonBlue
        )
        SystemInputField(
            value = academicGoals,
            onValueChange = onAcademicChange,
            label = "Academic Goals",
            placeholder = "e.g. Master Deep Work, Coursework, Literature",
            accentColor = CyberNeonBlue,
            minLines = 2
        )
        SystemInputField(
            value = healthGoals,
            onValueChange = onHealthChange,
            label = "Health Goals",
            placeholder = "e.g. 8h Sleep, Clean Diet, Hydration",
            accentColor = CyberNeonGreen,
            minLines = 2
        )
        SystemInputField(
            value = skillGoals,
            onValueChange = onSkillChange,
            label = "Skill Goals",
            placeholder = "e.g. Coding, Design, Instrument Mastery",
            accentColor = CyberNeonPurple,
            minLines = 2
        )
    }
}

@Composable
private fun Step2Routines(
    morning: String,
    onMorningChange: (String) -> Unit,
    afternoon: String,
    onAfternoonChange: (String) -> Unit,
    evening: String,
    onEveningChange: (String) -> Unit
) {
    Column {
        StepHeader(
            title = "Step 2: Daily Routines",
            subtitle = "Systematic daily protocols power rapid level growth.",
            icon = Icons.Default.Schedule,
            accentColor = CyberNeonGreen
        )
        SystemInputField(
            value = morning,
            onValueChange = onMorningChange,
            label = "Morning Routine",
            placeholder = "e.g. 6:30 AM wake, Hydration, Sunlight, Focus",
            accentColor = CyberNeonBlue,
            minLines = 2
        )
        SystemInputField(
            value = afternoon,
            onValueChange = onAfternoonChange,
            label = "Afternoon Routine",
            placeholder = "e.g. Deep block, Protein meal, Walk",
            accentColor = CyberGold,
            minLines = 2
        )
        SystemInputField(
            value = evening,
            onValueChange = onEveningChange,
            label = "Evening Routine",
            placeholder = "e.g. Review, Plan next day quests, 10 PM sleep",
            accentColor = CyberNeonPurple,
            minLines = 2
        )
    }
}

@Composable
private fun Step3Exercise(
    exercise: String,
    onExerciseChange: (String) -> Unit
) {
    Column {
        StepHeader(
            title = "Step 3: Exercise Routine",
            subtitle = "Physical conditioning multiplies energy & mental stamina.",
            icon = Icons.Default.FitnessCenter,
            accentColor = CyberNeonGreen
        )
        SystemInputField(
            value = exercise,
            onValueChange = onExerciseChange,
            label = "Exercise Routine Protocol",
            placeholder = "e.g. 100 Pushups, 100 Squats, 5km Run / Gym split",
            accentColor = CyberNeonGreen,
            minLines = 4
        )
    }
}

@Composable
private fun Step4LongTerm(
    yearly: String,
    onYearlyChange: (String) -> Unit,
    monthly: String,
    onMonthlyChange: (String) -> Unit
) {
    Column {
        StepHeader(
            title = "Step 4: Strategic Horizons",
            subtitle = "Anchor daily actions to your highest long-term visions.",
            icon = Icons.Default.Flag,
            accentColor = CyberGold
        )
        SystemInputField(
            value = yearly,
            onValueChange = onYearlyChange,
            label = "Yearly Goal",
            placeholder = "e.g. Launch venture, reach S-Rank level, 365 streak",
            accentColor = CyberGold,
            minLines = 2
        )
        SystemInputField(
            value = monthly,
            onValueChange = onMonthlyChange,
            label = "Monthly Goal",
            placeholder = "e.g. 90% quest completion rate & master 1 new topic",
            accentColor = CyberNeonBlue,
            minLines = 2
        )
    }
}

@Composable
private fun Step5User(
    userName: String,
    onUserNameChange: (String) -> Unit
) {
    Column {
        StepHeader(
            title = "Step 5: Hunter Registration",
            subtitle = "Enter your handle to bind the System to your identity.",
            icon = Icons.Default.Person,
            accentColor = CyberNeonBlue
        )
        SystemInputField(
            value = userName,
            onValueChange = onUserNameChange,
            label = "Hunter Name",
            placeholder = "e.g. Sung Jin-Woo / Shadow Hunter",
            accentColor = CyberNeonBlue,
            minLines = 1
        )
        Spacer(modifier = Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                .border(1.dp, CyberNeonBlue.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .padding(14.dp)
        ) {
            Column {
                Text(
                    text = "◆ SYSTEM CALIBRATION READY",
                    color = CyberNeonGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your custom daily quests, XP multiplier, radar web matrix, and commitment ledger will initialize immediately.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }
    }
}
