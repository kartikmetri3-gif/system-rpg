package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPurple
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.RadarStats
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SystemRadarChart(
    stats: RadarStats,
    modifier: Modifier = Modifier,
    isCompact: Boolean = false
) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(stats) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
        )
    }

    val textMeasurer = rememberTextMeasurer()

    val chartHeight = if (isCompact) 210.dp else 270.dp

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SystemCardBg, RoundedCornerShape(16.dp))
            .border(1.dp, SystemCardBorder, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(CyberNeonBlue, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "SKILLS WEB MATRIX",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            Text(
                text = "WEEKLY SYNC",
                color = CyberNeonGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(chartHeight),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(if (isCompact) 200.dp else 250.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.minDimension / 2f) * 0.72f

                // 3 Vertices angles for Academics (Top: -90 deg), Health (Bottom-Right: 30 deg), Skills (Bottom-Left: 150 deg)
                val angles = listOf(-90.0, 30.0, 150.0).map { Math.toRadians(it) }
                val labels = listOf("ACADEMICS", "HEALTH", "SKILLS")
                val colors = listOf(CyberNeonBlue, CyberNeonGreen, CyberNeonPurple)

                // 1. Draw Web / Grid Polygons (Levels 0.33, 0.66, 1.0)
                val gridLevels = listOf(0.33f, 0.66f, 1.0f)
                gridLevels.forEach { level ->
                    val gridPath = Path()
                    angles.forEachIndexed { i, angle ->
                        val r = radius * level
                        val x = (center.x + r * cos(angle)).toFloat()
                        val y = (center.y + r * sin(angle)).toFloat()
                        if (i == 0) gridPath.moveTo(x, y) else gridPath.lineTo(x, y)
                    }
                    gridPath.close()
                    drawPath(
                        path = gridPath,
                        color = Color(0x332E3C54),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }

                // 2. Draw Spokes / Axis Lines
                angles.forEachIndexed { i, angle ->
                    val endX = (center.x + radius * cos(angle)).toFloat()
                    val endY = (center.y + radius * sin(angle)).toFloat()
                    drawLine(
                        color = Color(0x4D384B68),
                        start = center,
                        end = Offset(endX, endY),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Draw Vertex Labels
                    val labelR = radius + 26.dp.toPx()
                    val labelX = (center.x + labelR * cos(angle)).toFloat()
                    val labelY = (center.y + labelR * sin(angle)).toFloat()

                    val textLayout = textMeasurer.measure(
                        text = labels[i],
                        style = TextStyle(
                            color = colors[i],
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(
                            labelX - textLayout.size.width / 2f,
                            labelY - textLayout.size.height / 2f
                        )
                    )
                }

                // 3. Draw Animated Data Polygon
                val p = animProgress.value
                val dataScores = listOf(
                    stats.academicsScore * p,
                    stats.healthScore * p,
                    stats.skillsScore * p
                )

                val dataPath = Path()
                val dataPoints = mutableListOf<Offset>()

                angles.forEachIndexed { i, angle ->
                    val r = radius * dataScores[i]
                    val x = (center.x + r * cos(angle)).toFloat()
                    val y = (center.y + r * sin(angle)).toFloat()
                    val pt = Offset(x, y)
                    dataPoints.add(pt)
                    if (i == 0) dataPath.moveTo(x, y) else dataPath.lineTo(x, y)
                }
                dataPath.close()

                // Fill with neon gradient
                drawPath(
                    path = dataPath,
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x7300E5FF),
                            Color(0x4000FF88),
                            Color(0x10BD00FF)
                        ),
                        center = center,
                        radius = radius
                    ),
                    style = Fill
                )

                // Draw Polygon Perimeter Glow
                drawPath(
                    path = dataPath,
                    brush = Brush.linearGradient(
                        colors = listOf(CyberNeonBlue, CyberNeonGreen, CyberNeonPurple)
                    ),
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw Vertex Nodes
                dataPoints.forEachIndexed { i, pt ->
                    drawCircle(
                        color = colors[i],
                        radius = 4.5.dp.toPx(),
                        center = pt
                    )
                    drawCircle(
                        color = Color.Black,
                        radius = 2.dp.toPx(),
                        center = pt
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Stat Badges Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            CategoryStatBadge("Academics", "${stats.academicsCompleted} Done", CyberNeonBlue)
            CategoryStatBadge("Health", "${stats.healthCompleted} Done", CyberNeonGreen)
            CategoryStatBadge("Skills", "${stats.skillsCompleted} Done", CyberNeonPurple)
        }
    }
}

@Composable
private fun CategoryStatBadge(
    title: String,
    value: String,
    accentColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = accentColor,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
