package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CommitmentDay
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.SystemBg
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCardBorder
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.SystemViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun CalendarScreen(
    viewModel: SystemViewModel,
    selectedMonth: YearMonth,
    commitmentDays: List<CommitmentDay>,
    modifier: Modifier = Modifier
) {
    val committedDateSet = commitmentDays.map { it.dateKey }.toSet()
    val currentStreak = viewModel.calculateCurrentStreak(commitmentDays)
    val bestStreak = viewModel.calculateBestStreak(commitmentDays)

    val today = viewModel.todayDate
    val todayKey = viewModel.todayDateKey
    val isTodayCommitted = committedDateSet.contains(todayKey)

    val daysInMonth = selectedMonth.lengthOfMonth()
    val firstDayOfWeek = selectedMonth.atDay(1).dayOfWeek.value // 1 (Mon) - 7 (Sun)
    val offset = (firstDayOfWeek - 1) // Days to skip before 1st of month

    val totalDaysInCurrentMonth = (1..daysInMonth).count { day ->
        val dateKey = selectedMonth.atDay(day).format(DateTimeFormatter.ISO_LOCAL_DATE)
        committedDateSet.contains(dateKey)
    }

    val completionRate = if (daysInMonth > 0) ((totalDaysInCurrentMonth.toFloat() / daysInMonth) * 100).toInt() else 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Calendar",
                            tint = CyberRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SYSTEM DISCIPLINE LEDGER",
                            color = CyberRed,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "COMMITMENT CALENDAR",
                        color = TextWhite,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Quick jump to today
                IconButton(
                    onClick = { viewModel.resetToCurrentMonth() },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFF1E2638), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Today,
                        contentDescription = "Current Month",
                        tint = CyberNeonBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        item {
            // Streak & Commitment Stats Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Streak Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SystemCardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(CyberOrange.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, CyberOrange, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak Fire",
                                tint = CyberOrange,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "STREAK",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "$currentStreak DAYS",
                                color = CyberOrange,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Monthly Rate Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SystemCardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(CyberRed.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, CyberRed, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Red X",
                                tint = CyberRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MONTH X'S",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "$totalDaysInCurrentMonth ($completionRate%)",
                                color = CyberRed,
                                fontSize = 15.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            // Calendar Grid Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calendar_grid_card"),
                colors = CardDefaults.cardColors(containerColor = SystemCardBg),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SystemCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Month Navigation Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.prevMonth() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Previous Month",
                                tint = CyberNeonBlue
                            )
                        }

                        Text(
                            text = selectedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")).uppercase(),
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        IconButton(onClick = { viewModel.nextMonth() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Next Month",
                                tint = CyberNeonBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Day of Week Headers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val dayNames = listOf("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
                        dayNames.forEach { dayName ->
                            Text(
                                text = dayName,
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Days Grid
                    val totalCells = offset + daysInMonth
                    val rows = (totalCells + 6) / 7

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (row in 0 until rows) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                for (col in 0 until 7) {
                                    val cellIndex = row * 7 + col
                                    val dayNum = cellIndex - offset + 1

                                    if (dayNum in 1..daysInMonth) {
                                        val dayDate = selectedMonth.atDay(dayNum)
                                        val dayKey = dayDate.format(DateTimeFormatter.ISO_LOCAL_DATE)
                                        val isCommitted = committedDateSet.contains(dayKey)
                                        val isCurrentDay = dayDate == today

                                        CalendarDayCell(
                                            dayNumber = dayNum,
                                            isCommitted = isCommitted,
                                            isToday = isCurrentDay,
                                            onClick = { viewModel.toggleCommitmentDay(dayKey) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    } else {
                                        // Empty spacer cell
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Legend & Tip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tap any day to toggle your Red 'X' Commitment",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            // Quick Today Action Button
            Button(
                onClick = { viewModel.markTodayCommitted() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("mark_today_committed_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isTodayCommitted) Color(0xFF1E293B) else CyberRed,
                    contentColor = if (isTodayCommitted) CyberNeonGreen else Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (isTodayCommitted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Committed",
                        tint = CyberNeonGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TODAY MARKED AS COMMITTED [X]",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Commit Today",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LOG TODAY AS COMMITTED",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CalendarDayCell(
    dayNumber: Int,
    isCommitted: Boolean,
    isToday: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cellBg by animateColorAsState(
        targetValue = when {
            isCommitted -> Color(0x33FF2A55)
            isToday -> Color(0xFF162235)
            else -> Color(0xFF0F141C)
        },
        label = "cellBg"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isCommitted -> CyberRed
            isToday -> CyberNeonBlue
            else -> SystemCardBorder
        },
        label = "cellBorder"
    )

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(cellBg)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (isCommitted) {
            // Big Red "X"
            Text(
                text = "X",
                color = CyberRed,
                fontSize = 20.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black
            )
            // Small day number in corner
            Text(
                text = "$dayNumber",
                color = TextWhite.copy(alpha = 0.7f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(3.dp)
            )
        } else {
            Text(
                text = "$dayNumber",
                color = if (isToday) CyberNeonBlue else TextWhite,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
