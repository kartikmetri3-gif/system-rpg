package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberNeonBlue,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF003847),
    onPrimaryContainer = CyberNeonBlue,
    secondary = CyberNeonGreen,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003B1F),
    onSecondaryContainer = CyberNeonGreen,
    tertiary = CyberNeonPurple,
    onTertiary = Color.White,
    background = SystemBg,
    onBackground = TextWhite,
    surface = SystemSurface,
    onSurface = TextWhite,
    surfaceVariant = SystemCardBg,
    onSurfaceVariant = TextMuted,
    outline = SystemCardBorder,
    error = CyberRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Gamified System is locked to immersive Dark Theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
